/******************************************************************************/
/*Files to Include                                                            */
/******************************************************************************/

#if defined(__XC)
    #include <xc.h>         /* XC8 General Include File */
#elif defined(HI_TECH_C)
    #include <htc.h>        /* HiTech General Include File */
#endif

#include <stdint.h>         /* For uint8_t definition */
#include <stdbool.h>        /* For true/false definition */
#include "user.h"

/******************************************************************************/
/* Interrupt Routines                                                         */
/******************************************************************************/

/* Baseline devices don't have interrupts. Note that some PIC16's 
 * are baseline devices.  Unfortunately the baseline detection macro is 
 * _PIC12 */
#ifndef _PIC12

void interrupt isr(void)
{
#if 1

    uint8_t ledcode;
    // If timer0 overflows update displays in chopper mode
    if(T0IF)
    {
        if (out==0) {
            PORTB = 0;
            ledcode = eeprom_read(DigitB);
            DSELECT = 1;
            PORTB = ledcode;
            out=1;
        }
        else {
            PORTB = 0;
            ledcode = eeprom_read(DigitA);
            DSELECT = 0;
            PORTB = ledcode;
            out=0;
        }
        T0IF=0; /* Clear Interrupt Flag 1 */
    }
    else {} // ALL other interrupts un-handled

#endif

}
#endif


