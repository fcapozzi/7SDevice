/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

#if defined(__XC)
    #include <xc.h>         /* XC8 General Include File */
#elif defined(HI_TECH_C)
    #include <htc.h>        /* HiTech General Include File */
#endif

#include <stdint.h>         /* For uint8_t definition */
#include <stdbool.h>        /* For true/false definition */

#include "user.h"

/******************************************************************************/
/* iNTERNAL EEPROM 7 Segment Display Table Preloading
/* The table starts at address 0 and list the "abcdefgh" code for each digit                                                             */
/******************************************************************************/

// Digit from 0 to 7
__EEPROM_DATA( 0x7B,0x60,0x37,0x75,0x6C,0x5D,0x5F,0x70 );

// Digit from 8 to F
__EEPROM_DATA( 0x7F,0x7C,0x7E,0x4F,0x1B,0x67,0x1F,0x1E );

// Digit H P L t - OFF
__EEPROM_DATA( 0x6E,0x3E,0x0B,0x0F,0x04,0x00,0x00,0x00 );

/******************************************************************************/
/* User Functions                                                             */
/******************************************************************************/

void InitApp(void)
{
   
  // RA0 : Output  (DigitSelect)
  // RA1 : Input   (SPI Protocol SCK pin from Master
  // RA2 : Input   (SPI Protocol MISO)
  // RA3 : Output  (SPI Protocol MOSI)
  // RA4 : Dont'care

     TRISA = 0b00010110;
     RA0 = 0;
     RA3 = 1;

  // RB0-RB7 Data bus to 7 Segment displays
     TRISB = 0;
     PORTB = 0;

  // Pull Up enabled on port B
  // timer0 Clock source internal
  // Prescaler Assigment to timer0
  // Prescaler set to 1/32
     
     OPTION_REG = 0b00000100;

  // Global Interrupt Enable
  // Timer0 Overflow Interrupt Enable

     INTCON = 0b10100100;

  // Timer0 overflow at a rate of 8.192 msec @ 4Mhz

     App_stato = Init;
}


APP_Task(void) {

    switch(App_stato) {
        case Init:
            for (int dgt=0;dgt<30000;dgt++);
            if ((MISO == 0) && (SCK == 0)) App_stato = TEST;
            else App_stato = Idle;
            break;
        case Idle:
            buffer = 0;
            reading_bit = 0;
            MOSI = 1;
            App_stato = WaitForClockDown;
            break;
        case WaitForClockDown:
            App_WDT++;
            if (SCK == 0) {
            // while(SCK != 0);
            App_WDT = 0;
            MOSI = 0;
            App_stato = WaitForClockUp;
            }
            if (App_WDT>WDT_TIMEOUT) App_stato = Idle;
            break;
        case WaitForClockUp:
            App_WDT++;
            if (SCK == 1) {
              // while(SCK != 1);
                App_WDT = 0;
              if (MISO == 1) buffer |= 0x01;
              else buffer &= 0xFE;
              reading_bit++;
              if (reading_bit == 8) App_stato = UpdateDigit;
              else {
                  buffer = buffer <<1;
                  App_stato = WaitForClockDown;
              }
              MOSI = 1;  // valutare se mettere a 0
            }
            if (App_WDT>WDT_TIMEOUT) App_stato = Idle;
            break;
        case UpdateDigit:
            if (dgt==0) DigitA = buffer;
            else DigitB = buffer;
            dgt = !dgt;
            MOSI = 1;
            App_stato = Idle;
            break;
        case TEST :
            for (int buffer=0;buffer<22;buffer++){
            DigitA = buffer;
            for (int dgt=0;dgt<22;dgt++) {
                DigitB = dgt;
                for (App_WDT = 0;App_WDT < 15000;App_WDT++) {}
            }
            }
    }
}
