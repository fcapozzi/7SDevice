/******************************************************************************/
/* User Level #define Macros                                                  */
/******************************************************************************/

#define MISO    RA2
#define MOSI    RA3
#define SCK     RA1
#define DSELECT RA0

#define WDT_TIMEOUT 30000   // timeout in 150 msec @4Mhz

/******************************************************************************/
/* User Function Prototypes                                                   */
/******************************************************************************/

volatile uint8_t DigitA,DigitB,out;

typedef enum APP_STATO {
            Init,
            Idle,
            WaitForClockDown,
            WaitForClockUp,
            UpdateDigit,
            TEST,
            ERROR
} stato ;

stato App_stato;
volatile uint8_t dgt=0;
volatile uint16_t App_WDT=0;
volatile uint8_t  reading_bit=0;
volatile uint8_t  buffer;

void InitApp(void);         /* I/O and Peripheral Initialization */
void App_Task(void);
