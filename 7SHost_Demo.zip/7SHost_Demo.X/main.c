/* 
 * File:   main.c
 * Author: root
 *
 * Created on 25 febbraio 2014, 10.52
 */

#include <stdio.h>
#include <stdlib.h>
#include <p32xxxx.h>
#include <plib.h>
#include <inttypes.h>

// PIC32MX250F128B Configuration Bit Settings

#include <xc.h>

// DEVCFG3
// USERID = No Setting
#pragma config PMDL1WAY = OFF           // Peripheral Module Disable Configuration (Allow multiple reconfigurations)
#pragma config IOL1WAY = OFF            // Peripheral Pin Select Configuration (Allow multiple reconfigurations)
#pragma config FUSBIDIO = ON            // USB USID Selection (Controlled by the USB Module)
#pragma config FVBUSONIO = ON           // USB VBUS ON Selection (Controlled by USB Module)

// DEVCFG2
#pragma config FPLLIDIV = DIV_2         // PLL Input Divider (2x Divider)
#pragma config FPLLMUL = MUL_20         // PLL Multiplier (20x Multiplier)
#pragma config UPLLIDIV = DIV_2         // USB PLL Input Divider (2x Divider)
#pragma config UPLLEN = OFF             // USB PLL Enable (Disabled and Bypassed)
#pragma config FPLLODIV = DIV_2         // System PLL Output Clock Divider (PLL Divide by 2)

// DEVCFG1
#pragma config FNOSC = PRIPLL           // Oscillator Selection Bits (Primary Osc w/PLL (XT+,HS+,EC+PLL))
#pragma config FSOSCEN = OFF            // Secondary Oscillator Enable (Disabled)
#pragma config IESO = OFF               // Internal/External Switch Over (Disabled)
#pragma config POSCMOD = HS             // Primary Oscillator Configuration (HS osc mode)
#pragma config OSCIOFNC = OFF           // CLKO Output Signal Active on the OSCO Pin (Disabled)
#pragma config FPBDIV = DIV_2           // Peripheral Clock Divisor (Pb_Clk is Sys_Clk/2)
#pragma config FCKSM = CSDCMD           // Clock Switching and Monitor Selection (Clock Switch Disable, FSCM Disabled)
#pragma config WDTPS = PS1048576        // Watchdog Timer Postscaler (1:1048576)
#pragma config WINDIS = OFF             // Watchdog Timer Window Enable (Watchdog Timer is in Non-Window Mode)
#pragma config FWDTEN = OFF             // Watchdog Timer Enable (WDT Disabled (SWDTEN Bit Controls))
#pragma config FWDTWINSZ = WISZ_25      // Watchdog Timer Window Size (Window Size is 25%)

// DEVCFG0
#pragma config JTAGEN = OFF             // JTAG Enable (JTAG Disabled)
#pragma config ICESEL = ICS_PGx2        // ICE/ICD Comm Channel Select (Communicate on PGEC2/PGED2)
#pragma config PWP = OFF                // Program Flash Write Protect (Disable)
#pragma config BWP = OFF                // Boot Flash Write Protect bit (Protection Disabled)
#pragma config CP = OFF                 // Code Protect (Protection Disabled)

#define SCK   LATBbits.LATB5
#define MISO  PORTBbits.RB4
#define MOSI  LATAbits.LATA4

#define DISPLAY_TIMEOUT 65               // 65 * 3.2 usec = 208 usec
#define START_TIMER 1000                 // 1000 * 3.2 usec = 3.2 msec

typedef enum  {
       Init,
       Idle,
       WaitForDeviceReady,
       WaitForDeviceAck,
       WaitForReceiveOK,
       eot
    } t_stato;

volatile uint32_t startup, counter=0;

volatile struct {
    uint8_t digitA;
    uint8_t digitB;
    t_stato stato;
    uint8_t Bit;
    uint8_t dgt;    // 0 for sending A  1 for sending B
    uint32_t Disp_WDT;
} Display;


void SystemInit() {

    // Preload Structure
      Display.digitA = 0x0F;
      Display.digitB = 0x0F;
      Display.dgt = 0;
      Display.Bit = 0;
      Display.stato = Init;
      Display.Disp_WDT = DISPLAY_TIMEOUT;
      startup = 0;

    // Disable Analog Peripheral
       ANSELA = 0;
       ANSELB = 0;

    // Set port A direction RA0, RA4(MOSI)output;
       LATA = 0x0010;
       TRISACLR = 0x0011;

    // Set port B direction RB5(SCK) output   RB4(MISO) input
       TRISBCLR = 0x0020;
       TRISBSET = 0x0010;
       LATB = 0x0030;

    // Configure timer1
    // PBCLOCK is 20 Mhz - timer1 increment at PBCLOCK/64 = 3.2 usec
    // Interrupt flag at 32 * 3.2 usec = 102.4 usec
       T1CONbits.ON = 0;          // Disable timer 1
       T1CONbits.TCS = 0;         // Set clock source to be PBCLCK
       T1CONbits.TCKPS = 2;       // Set prescaler to 1/64
       T1CONbits.TGATE = 0;       // Set Gated Timer accumulation disable
       PR1 = 32;                  // Preload timer compare register
       T1CONbits.ON = 1;          // Enable timer 1

       INTEnableSystemMultiVectoredInt();

    // Configure interrupts for Timer 1   IRQ 4   Vector 4
    // IECO<4> IFS0<4>  Pri IPC1<4:2>   SubPri IPC1<0:1>
       IEC0CLR = 0x0010;          // Disable interrupts for timer1
       IPC1CLR = 0x001C;          // Clear priority and subpriority
       IPC1SET = 0x0008;          // Set priority 2 Subpri 0 for timer 1
       IFS0CLR = 0x0010;          // Clear flag for IRQ4
       IEC0SET = 0x0010;          // Enable Interrupts for timer1
}


void __ISR(4,ipl2) Timer1_Display_Handler(void) {

    uint8_t ch,aux;
    if (Display.dgt) ch = Display.digitB;
    else ch = Display.digitA;
    switch(Display.stato) {
        case Init:
            startup++;
            if (startup > START_TIMER) Display.stato = Idle;
            break;
        case Idle :
            Display.Disp_WDT++;
            SCK = 1;
            if (MISO == 1)  { 
                Display.Disp_WDT = 0;
                Display.stato = WaitForDeviceReady;
            }
            if (Display.Disp_WDT > DISPLAY_TIMEOUT) {
                Display.Bit = 0;
                Display.dgt = 0;
                Display.stato = Idle;
                Display.Disp_WDT = 0;
            }
            break;
        case WaitForDeviceReady :
            Display.Disp_WDT++;
            SCK = 0;
            if (MISO == 0) {
                Display.Disp_WDT = 0;
                aux = (ch << Display.Bit) & 0x80;
                if (aux == 0x80) MOSI = 1;
                else MOSI = 0;
                Display.Bit++;
                SCK = 1;
                Display.stato = WaitForDeviceAck;
            }
            if (Display.Disp_WDT > DISPLAY_TIMEOUT) {
                Display.Bit = 0;
                Display.dgt = 0;
                Display.stato = Idle;
                Display.Disp_WDT = 0;
            }
            break;
        case WaitForDeviceAck :
            Display.Disp_WDT++;
            if (MISO == 1) {
                Display.Disp_WDT = 0;
                if (Display.Bit == 8) Display.stato = eot;
                else Display.stato = WaitForDeviceReady;
            }
            if (Display.Disp_WDT > DISPLAY_TIMEOUT) {
                Display.Bit = 0;
                Display.dgt = 0;
                Display.stato = Idle;
                Display.Disp_WDT = 0;
            }
            break;
        case eot:
            Display.Bit = 0;
            Display.dgt = !Display.dgt;
            Display.stato = Idle;
            Display.Disp_WDT = 0;
            break;
    }

    counter++;
    if (counter == 750) {
        LATAINV = 0x0001;
        counter = 0;
    }

    IFS0CLR = 0x0010;
}

int main(int argc, char** argv) {

    int i,j,k;
    SystemInit();
    while (1) {
        for (i=0;i<10;i++)
        for (j=0;j<10;j++) {
             Display.digitA = i;
             Display.digitB = j;
             for (k=0;k<500000;k++);
        }
    }

    return (EXIT_SUCCESS);
}

