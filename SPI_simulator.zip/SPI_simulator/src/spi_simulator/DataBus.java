

package spi_simulator;

public class DataBus {
    
    boolean miso;
    boolean mosi;
    boolean clk;
    
}
