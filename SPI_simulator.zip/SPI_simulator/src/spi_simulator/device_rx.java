

package spi_simulator;

/**
 *
 * @author fabio
 */

public class device_rx extends Thread {
    
  fifo buffer;
  int ch;
  DataBus device_bus;
  enum t_stato {Init,WaitForClkDown,WaitForClkUp,UpdateBuffer};
    
  device_rx(DataBus bus, fifo buf){
     device_bus = bus;
     buffer = buf;
     ch = 0;
  }
    
  public void run () {
        
     t_stato stato;
     stato = t_stato.Init;
     int bit=0;
     char c;
       
     while(true) {
     switch(stato) {
         case Init:
             ch = 0;
             System.out.println(Ansi.RED+"\treceive init"+Ansi.RESET);
             bit = 0;
             device_bus.miso = true;
             System.out.println(Ansi.RED+"\treceive assert miso up"+Ansi.RESET);
             stato = t_stato.WaitForClkDown;
             break;
        case WaitForClkDown :
             System.out.println(Ansi.RED+"\treceive WaitForClockDown"+
                                Ansi.RESET);            
             while (device_bus.clk != false);
             System.out.println(Ansi.RED+"\treceive got clock down"+Ansi.RESET);
             device_bus.miso = false;
             System.out.println(Ansi.RED+"\treceive assert miso down"+
                                Ansi.RESET);
             stato = t_stato.WaitForClkUp;
             break;
         case WaitForClkUp :
             System.out.println(Ansi.RED+"\treceive WaitForClockUp"+Ansi.RESET);
             while (device_bus.clk != true);
             System.out.println(Ansi.RED+"\treceive got clock up"+Ansi.RESET);
             if (device_bus.mosi == true) ch |= 0x01;
             else ch &= 0xFE;      
             System.out.println(Ansi.RED+"\treceive Got bit : "+
                                bit+"  ch = "+ch+Ansi.RESET);              
             bit++;              
             if (bit == 8) stato = t_stato.UpdateBuffer;
             else {
                 ch = ch << 1;
                 stato = t_stato.WaitForClkDown;
             }
             device_bus.miso = true;
             System.out.println(Ansi.RED+"\treceive assert miso up"+Ansi.RESET);
             break;             
         case UpdateBuffer:
             c = (char) ch;
             System.out.println(Ansi.RED+"\treceive UpdateBuffer"+Ansi.RESET);
             buffer.push(ch);
             System.out.println(Ansi.GREEN+"\treceive Got char  "+
                                ch+" ASCII : "+c+Ansi.RESET);
             device_bus.miso = true;
             System.out.println(Ansi.RED+"\treceive assert miso up"+Ansi.RESET);
             stato = t_stato.Init;
       }
       }
    }
    
}
