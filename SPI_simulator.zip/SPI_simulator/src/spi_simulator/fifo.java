/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package spi_simulator;

/**
 *
 * @author fabio
 */
public class fifo {
 
    fifo first;
    fifo current;
    Object o;
    fifo next;
    
    fifo () {
        first = this;
        current = this;
        o = null;
        next = null;
    }
    
    void push (Object o) {
        fifo p;
        p = first;
        while (p.o != null) p=p.next;
        p.o = o;
        p.next = new fifo();
    }
    
    Object pop() {
        Object o;
        o = first.o;
        first = first.next;
        return o;
    }
    
    void print() {
        fifo p;
        char c;
        p=first;
        while(p.o!=null) {
            c = (char) ((int) p.o);
            System.out.print(c);
            p = p.next;
        }
        System.out.println();
    }
}
