

package spi_simulator;

/**
 *
 * @author fabio
 */
public class host_tx {
    
    DataBus host_bus;
    enum t_stato {Init,WaitForDeviceReady,WaitForDeviceAck,WaitForReceiveOK,eot}
    
    host_tx(DataBus system_bus) {
        host_bus = system_bus;
    }
    
  
    void send_message(String s) {
        t_stato stato;      
        int i;
        int bit=0;
        int ch;
        int aux;
        
        for (i=0;i<s.length();i++) {
            System.out.println(Ansi.BLUE+"***** Sending char at s["+i+"] = "+
                    s.charAt(i)+Ansi.RESET);
            stato = t_stato.Init;
            bit = 0;
            while (stato != t_stato.eot) {
               ch = (int) s.charAt(i); 
                switch (stato) {
                    case Init :
                        System.out.println("send - Init - Sending ch="+ch);
                        host_bus.clk = true;
                        System.out.println("send - Assert clock up");
                        while (host_bus.miso != true);
                        stato = t_stato.WaitForDeviceReady;
                        break;
                    case WaitForDeviceReady :
                        System.out.println("send - WaitForDeviceReady");
                        host_bus.clk = false;
                        System.out.println("send - Assert clock down");
                        while (host_bus.miso != false);
                        aux = (ch << bit) & 0x80;
                        if (aux == 0x80) host_bus.mosi = true;
                        else host_bus.mosi = false;
                        System.out.println("send - Sent bit "+bit+" aux= "+aux);
                        bit = bit+1;
                        host_bus.clk = true;
                        System.out.println("send - Assert clock up");
                        stato = t_stato.WaitForDeviceAck;
                        break;
                    case WaitForDeviceAck :
                        System.out.println("send - WaitForDeviceAck");
                        while (host_bus.miso != true);
                        if (bit == 8) stato = t_stato.eot;
                        else stato = t_stato.WaitForDeviceReady;
                        break;
                    case eot :
                        System.out.println("send - eot");
                        break;
            }
               
        }  
    }
} 
    
}
