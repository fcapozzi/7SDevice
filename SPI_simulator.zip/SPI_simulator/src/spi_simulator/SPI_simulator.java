

package spi_simulator;

/**
 *
 * @author fabio
 */
public class SPI_simulator {
   


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
     fifo rxbuf;
     rxbuf = new fifo();
     DataBus sbus;
     sbus = new DataBus();
     device_rx  device;
     device = new device_rx(sbus,rxbuf);
     device.start();
    
     host_tx sender;
     sender = new host_tx(sbus);
     sender.send_message("The quick");
     // sender.send_message("A");
     device.stop();
     rxbuf.print();     
   }
}
